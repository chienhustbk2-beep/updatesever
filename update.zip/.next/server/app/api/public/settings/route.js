var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/public/settings/route.js")
R.c("server/chunks/[root-of-the-server]__0ja2wc7._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0qxoqbu._.js")
R.c("server/chunks/_next-internal_server_app_api_public_settings_route_actions_001zj2k.js")
R.m(50917)
module.exports=R.m(50917).exports
