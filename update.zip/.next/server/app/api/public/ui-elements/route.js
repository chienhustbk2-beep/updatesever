var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/public/ui-elements/route.js")
R.c("server/chunks/[root-of-the-server]__05eayxm._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0qxoqbu._.js")
R.c("server/chunks/_next-internal_server_app_api_public_ui-elements_route_actions_0fe4gf~.js")
R.m(59980)
module.exports=R.m(59980).exports
