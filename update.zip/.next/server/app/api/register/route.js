var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/register/route.js")
R.c("server/chunks/[root-of-the-server]__11qj0sj._.js")
R.c("server/chunks/_0qxoqbu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_131y~ke.js")
R.c("server/chunks/node_modules_bcryptjs_index_0bjz0ul.js")
R.c("server/chunks/_next-internal_server_app_api_register_route_actions_0h~hv89.js")
R.m(16421)
module.exports=R.m(16421).exports
