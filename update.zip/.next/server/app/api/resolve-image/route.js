var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/resolve-image/route.js")
R.c("server/chunks/[root-of-the-server]__0ymzrbt._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_resolve-image_route_actions_12n7-32.js")
R.m(32830)
module.exports=R.m(32830).exports
