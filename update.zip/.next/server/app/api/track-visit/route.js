var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/track-visit/route.js")
R.c("server/chunks/[root-of-the-server]__06b265p._.js")
R.c("server/chunks/_0qxoqbu._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_track-visit_route_actions_113d2ft.js")
R.m(4166)
module.exports=R.m(4166).exports
