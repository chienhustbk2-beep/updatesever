var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/uploads/[...filename]/route.js")
R.c("server/chunks/[root-of-the-server]__09uq1a7._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_uploads_[___filename]_route_actions_0tdxodt.js")
R.m(49115)
module.exports=R.m(49115).exports
