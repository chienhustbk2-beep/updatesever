var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/web2m/sync/route.js")
R.c("server/chunks/[root-of-the-server]__0m6pidf._.js")
R.c("server/chunks/_0qxoqbu._.js")
R.c("server/chunks/[root-of-the-server]__00uv3lo._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_web2m_sync_route_actions_13r7928.js")
R.m(11992)
module.exports=R.m(11992).exports
