module.exports=[61047,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_dashboard-stats_route_actions_0wa2dh6.js.map