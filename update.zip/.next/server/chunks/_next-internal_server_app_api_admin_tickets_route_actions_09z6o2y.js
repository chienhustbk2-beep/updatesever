module.exports=[84399,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_tickets_route_actions_09z6o2y.js.map