module.exports=[14761,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_ui-elements_route_actions_0crlh0u.js.map