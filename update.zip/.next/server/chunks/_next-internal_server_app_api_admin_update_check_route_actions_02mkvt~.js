module.exports=[16337,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_update_check_route_actions_02mkvt~.js.map