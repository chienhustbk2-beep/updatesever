module.exports=[71007,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_update_route_actions_0yk~jj~.js.map