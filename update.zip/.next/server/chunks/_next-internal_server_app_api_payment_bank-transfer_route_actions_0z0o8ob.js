module.exports=[93379,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_payment_bank-transfer_route_actions_0z0o8ob.js.map