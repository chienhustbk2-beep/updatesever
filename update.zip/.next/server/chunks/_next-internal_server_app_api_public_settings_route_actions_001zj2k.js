module.exports=[33642,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_public_settings_route_actions_001zj2k.js.map