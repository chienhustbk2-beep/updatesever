module.exports=[33077,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_resolve-image_route_actions_12n7-32.js.map