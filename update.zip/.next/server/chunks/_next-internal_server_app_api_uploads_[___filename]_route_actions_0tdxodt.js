module.exports=[29482,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_uploads_%5B___filename%5D_route_actions_0tdxodt.js.map