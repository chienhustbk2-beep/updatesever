module.exports=[24223,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_orders_%5Bid%5D_pay_route_actions_04y7zjn.js.map