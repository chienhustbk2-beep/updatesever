module.exports=[82988,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_orders_%5Bid%5D_route_actions_0~482~w.js.map