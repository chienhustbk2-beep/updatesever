module.exports=[37779,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_orders_route_actions_0qtkd~9.js.map