module.exports=[70392,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_recent-deposit_route_actions_0v0r4y5.js.map