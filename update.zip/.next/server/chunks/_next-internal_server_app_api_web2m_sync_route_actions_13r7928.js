module.exports=[32772,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_web2m_sync_route_actions_13r7928.js.map