module.exports=[55591,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_ui-customization_page_actions_0s.iuzr.js.map