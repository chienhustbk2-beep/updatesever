module.exports=[78985,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_update_page_actions_03s25ri.js.map