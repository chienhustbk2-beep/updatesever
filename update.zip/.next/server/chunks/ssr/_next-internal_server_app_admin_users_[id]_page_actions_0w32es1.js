module.exports=[96915,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_users_%5Bid%5D_page_actions_0w32es1.js.map