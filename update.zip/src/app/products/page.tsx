import { prisma } from '@/lib/prisma';import ProductCard from '@/components/ui/ProductCard';import ProductFilter from '@/components/ui/ProductFilter';import Link from 'next/link';import { ChevronLeft, ChevronRight } from 'lucide-react';
const ITEMS_PER_PAGE = 12
interface ProductsPageProps { searchParams: Promise<{ q?: string; category?: string; type?: string; sort?: string; page?: string; priceMin?: string; priceMax?: string }>}
export default async function ProductsPage({ searchParams }: ProductsPageProps) {  const params = await searchParams; const query = params.q || '';
const categorySlug = params.category || '';const type = params.type || '';
const sort = params.sort || 'newest';
const page = parseInt(params.page || '1');
  const priceMin = params.priceMin ? parseFloat(params.priceMin) : undefined; const priceMax = params.priceMax ? parseFloat(params.priceMax) : undefined;
const where: Record<string, unknown> = { status: 'ACTIVE' }
if (query) {    (where as Record<string, unknown>).OR = [      { name: { contains: query } },      { description: { contains: query } },      { shortDesc: { contains: query } },    ]  }
if (categorySlug) {    const cat = await prisma.category.findUnique({ where: { slug: categorySlug } })
  if (cat) (where as Record<string, unknown>).categoryId = cat.id  }
if (type) (where as Record<string, unknown>).type = type; if (priceMin !== undefined || priceMax !== undefined) {    const priceFilter: Record<string, number> = {}
if (priceMin !== undefined) priceFilter.gte = priceMin; if (priceMax !== undefined) priceFilter.lte = priceMax; const priceCondition = {      OR: [        { salePrice: priceFilter },        { AND: [{ salePrice: null }, { price: priceFilter }] },      ]}
const existingOr = (where as Record<string, unknown>).OR; if (existingOr && Array.isArray(existingOr) && existingOr.length > 0) {      (where as Record<string, unknown>).AND = [        ...(existingOr as Array<Record<string, unknown>>),        priceCondition,      ];      delete (where as Record<string, unknown>).OR    } else {      Object.assign(where, priceCondition)    }  }
const orderBy: Record<string, 'asc' | 'desc'> = {};switch (sort) {    case 'price-asc':      orderBy.salePrice = 'asc';      break;    case 'price-desc':      orderBy.salePrice = 'desc';      break;    case 'name':      orderBy.name = 'asc';      break; default:      orderBy.createdAt = 'desc';  }
const [products, total] = await Promise.all([    prisma.product.findMany({      where,      orderBy,      skip: (page - 1) * ITEMS_PER_PAGE,      take: ITEMS_PER_PAGE,      include: {        bulkDiscounts: true,      },    }),    prisma.product.count({ where }),  ]);
  const productIds = products.map(p => p.id);
  const availableGroups = productIds.length > 0 ? await prisma.productKey.groupBy({
    by: ["productId"],
    _count: { id: true },
    where: { productId: { in: productIds }, status: "AVAILABLE" },
  }) : [];
  const availableMap = new Map(availableGroups.map(g => [g.productId, g._count.id]));
  const productsWithStock = products.map(p => ({ ...p, stock: availableMap.get(p.id) ?? 0 }));
  const categories = await prisma.category.findMany({ orderBy: { name: 'asc' } })
  const totalPages = Math.ceil(total / ITEMS_PER_PAGE);
return (    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">      {/* Search & Filter - Top */}      <ProductFilter categories={categories} totalProducts={total} />      {/* Breadcrumb */}      <nav className="mb-4 text-sm text-muted">        <Link href="/" className="hover:text-divine-blue">Trang chủ</Link>        <span className="mx-2">/</span>        <span className="text-white">Sản phẩm</span>      </nav>      {/* Header */}      <div className="mb-6">        <h1 className="text-3xl font-extrabold gradient-heading">          Tất cả sản phẩm        </h1>      </div>      {/* Products Grid */}      {products.length === 0 ? (        <div className="flex flex-col items-center justify-center py-20 text-muted">          <p className="text-lg font-medium">Không tìm thấy sản phẩm nào</p>          <p className="text-sm mt-1">Thử thay đổi bộ lọc hoặc từ khóa tìm kiếm</p>        </div>      ) : (        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">          {productsWithStock.map((product) => (
            <ProductCard
              key={product.id}
              product={{
                id: product.id,
                name: product.name,
                slug: product.slug,
                price: product.price,
                salePrice: product.salePrice,
                images: product.images,
                stock: product.stock,
                status: product.status,
                bulkDiscounts: product.bulkDiscounts,
              }}
            />
          ))}        </div>      )}      {/* Pagination */}      {totalPages > 1 && (        <div className="mt-12 flex items-center justify-center gap-2">          {page > 1 && (            <Link              href={`?${new URLSearchParams({ q: query, category: categorySlug, type, sort, page: String(page - 1), priceMin: priceMin?.toString() || '', priceMax: priceMax?.toString() || '' })}`}              className="flex items-center gap-1 rounded-lg bg-card px-3 py-2 text-sm text-muted transition hover:bg-main border border-divider"            >              <ChevronLeft className="h-4 w-4" />              Trước            </Link>          )}          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {            let p: number; if (totalPages <= 5) {              p = i + 1            } else; if (page <= 3) {              p = i + 1            } else; if (page >= totalPages - 2) {              p = totalPages - 4 + i            } else {              p = page - 2 + i            }
return (              <Link                key={p}                href={`?${new URLSearchParams({ q: query, category: categorySlug, type, sort, page: String(p), priceMin: priceMin?.toString() || '', priceMax: priceMax?.toString() || '' })}`}                className={`flex h-10 w-10 items-center justify-center rounded-lg text-sm font-medium transition ${                  p === page                    ? 'bg-primary text-white'                    : 'bg-card text-muted hover:bg-main border border-divider'                }`}              >                {p}              </Link>            )          })}          {page < totalPages && (            <Link              href={`?${new URLSearchParams({ q: query, category: categorySlug, type, sort, page: String(page + 1), priceMin: priceMin?.toString() || '', priceMax: priceMax?.toString() || '' })}`}              className="flex items-center gap-1 rounded-lg bg-card px-3 py-2 text-sm text-muted transition hover:bg-main border border-divider"            >              Sau              <ChevronRight className="h-4 w-4" />            </Link>          )}        </div>      )}    </div>  )}
